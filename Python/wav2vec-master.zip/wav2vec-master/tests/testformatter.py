from wav2vec.formatter import Formatter
import unittest

# TODO: maybe write some unit tests for Formatter. For now the validation tests
# should do.
