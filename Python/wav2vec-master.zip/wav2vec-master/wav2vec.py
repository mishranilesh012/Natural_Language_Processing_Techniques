#!/usr/bin/env python
from wav2vec import main

if __name__ == "__main__":
    main.main()
